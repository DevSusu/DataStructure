#ifndef _COMPLEX_H_
#define _COMPLEX_H_

class Complex {
public:
    Complex();
    Complex(int re, int im);
    
    Complex operator+(Complex& com);
    Complex operator-(Complex& com);
    Complex operator*(Complex& com);
    friend std::ostream& operator<<(std::ostream& os, const Complex& com);
    
private:
    int re, im;
};

#endif